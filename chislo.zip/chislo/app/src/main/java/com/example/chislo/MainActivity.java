package com.example.chislo;


import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.view.View;


public class MainActivity extends Activity {

    TextView tvInfo;
    EditText etInput;
    Button bControl;
    int chislo1;
    boolean finish;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvInfo = (TextView)findViewById(R.id.textView4);
        etInput = (EditText)findViewById(R.id.editTextNumber12);
        bControl = (Button)findViewById(R.id.button8);

        chislo1 = (int)(Math.random()*100);
        finish = false;
    }

    public void onClick(View v) {
        if (!finish) {
            int inp=Integer.parseInt(etInput.getText().toString());
            if (inp > chislo1)
                tvInfo.setText(getResources().getString(R.string.ahead));
            if (inp < chislo1)
                tvInfo.setText(getResources().getString(R.string.behind));
            if (inp == chislo1) {
                tvInfo.setText(getResources().getString(R.string.hit));
                bControl.setText(getResources().getString(R.string.play_more));
                finish = true;
            }
        }
        else
        {
            chislo1= (int)(Math.random()*100);
            bControl.setText(getResources().getString(R.string.input_value));
            tvInfo.setText(getResources().getString(R.string.try_to_guess));
            finish = false;
        }
            etInput.setText("");
    }
}