package com.example.images_23;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Thursday extends AppCompatActivity {

    EditText editText;
    Button btnTh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tuesday);
        editText = (EditText) findViewById(R.id.edtThursday);
        btnTh = (Button) findViewById(R.id.btnThursday);
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("task", editText.getText().toString());
                setResult(RESULT_OK, intent);
                finish();
            }
        };
        btnTh.setOnClickListener(clickListener);
    }
}