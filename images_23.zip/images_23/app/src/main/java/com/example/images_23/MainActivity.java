package com.example.images_23;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button btnMonday, btnTuesday, btnWednesday, btnThursday, btnFriday, btnSatturday, btnSunday;
    TextView tvMonday, tvTuesday, tvWednesday, tvThursday, tvFriday, tvSatturday, tvSunday;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnMonday = findViewById(R.id.btnDay1);
        btnTuesday = findViewById(R.id.btnDay2);
        btnWednesday = findViewById(R.id.btnDay3);
        btnThursday = findViewById(R.id.btnDay4);
        btnFriday = findViewById(R.id.btnDay5);
        btnSatturday = findViewById(R.id.btnDay6);
        btnSunday = findViewById(R.id.btnDay7);
        tvMonday = findViewById(R.id.tvDay1);
        tvTuesday = findViewById(R.id.tvDay2);
        tvWednesday = findViewById(R.id.tvDay3);
        tvThursday = findViewById(R.id.tvDay4);
        tvFriday = findViewById(R.id.tvDay5);
        tvSatturday = findViewById(R.id.tvDay6);
        tvSunday = findViewById(R.id.tvDay7);
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                switch (view.getId()){
                    case R.id.btnDay1:
                        intent = new Intent(MainActivity.this, Monday.class);
                        startActivityForResult(intent, 1);
                        break;
                    case R.id.btnDay2:
                        intent = new Intent(MainActivity.this, Tuesday.class);
                        startActivityForResult(intent, 2);
                        break;
                    case R.id.btnDay3:
                        intent = new Intent(MainActivity.this, Wednesday.class);
                        startActivityForResult(intent, 3);
                        break;
                    case R.id.btnDay4:
                        intent = new Intent(MainActivity.this, Thursday.class);
                        startActivityForResult(intent, 4);
                        break;
                }
            }
        };
        btnMonday.setOnClickListener(clickListener);
        btnTuesday.setOnClickListener(clickListener);
        btnWednesday.setOnClickListener(clickListener);
        btnThursday.setOnClickListener(clickListener);
        btnFriday.setOnClickListener(clickListener);
        btnSatturday.setOnClickListener(clickListener);
        btnSunday.setOnClickListener(clickListener);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String task = data.getStringExtra("task");
        if (requestCode == 1) {
            setTextonTV(tvMonday, task);
        } else if (requestCode == 2) {
            setTextonTV(tvTuesday, task);
        } else if (requestCode == 3) {
            setTextonTV(tvWednesday, task);
        } else if (requestCode == 4) {
            setTextonTV(tvThursday, task);
        }
    }


    private void setTextonTV(TextView tv, String task){
        if (task.equals("")) {
            task = "Дел на сегодня не запланировано";
            tv.setText(task);
            return;
        }
        tv.setText(task);
    }
}